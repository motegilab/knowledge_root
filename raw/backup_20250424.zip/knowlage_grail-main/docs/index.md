# Knowledge Grail

ようこそ！このサイトは GPT & 人間が共通で扱うプロジェクトの「聖杯」です。
