# knowlage_grail
 Holy‑Grail Repo
## Quick Start (5-step)
1. Clone or download ZIP
2. Open docs/gpt_snapshot.md to sync with GPT
3. Edit any docs/*.md → Commit
4. Update gpt_snapshot.md (copy-paste)
5. Optional: Download ZIP backup weekly
